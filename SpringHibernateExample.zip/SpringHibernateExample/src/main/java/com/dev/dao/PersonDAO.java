package com.dev.dao;

import java.util.List;

import com.dev.model.Person;

public interface PersonDAO {

	public void save(Person p);
	
	public List<Person> list();
	
}
